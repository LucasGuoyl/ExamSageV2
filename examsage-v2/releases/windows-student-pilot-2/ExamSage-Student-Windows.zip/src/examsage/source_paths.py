import os
from pathlib import Path


def source_path(path: Path) -> Path:
    """Absolute filesystem spelling for source copies and their staging trees."""
    value = str(path.resolve())
    if os.name == 'nt' and not value.startswith('\\\\?\\'):
        value = '\\\\?\\UNC\\' + value[2:] if value.startswith('\\\\') else '\\\\?\\' + value
    return Path(value)
